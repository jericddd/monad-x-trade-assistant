import { HardhatUserConfig } from "hardhat/config";
import "@nomicfoundation/hardhat-toolbox";
import * as dotenv from "dotenv";

dotenv.config();

const config: HardhatUserConfig = {
  solidity: "0.8.24",
  paths: {
    sources: "./",
    tests: "./test",
    cache: "./cache",
    artifacts: "./artifacts",
  },
  networks: {
    monadMainnet: {
      url: process.env.MONAD_RPC_URL ?? "https://rpc.monad.xyz",
      chainId: 143,
      accounts: process.env.MINT_WALLET_PRIVATE_KEY
        ? [process.env.MINT_WALLET_PRIVATE_KEY.startsWith("0x")
            ? process.env.MINT_WALLET_PRIVATE_KEY
            : `0x${process.env.MINT_WALLET_PRIVATE_KEY}`]
        : [],
    },
    localhost: {
      url: "http://127.0.0.1:8545",
    },
  },
};

export default config;
