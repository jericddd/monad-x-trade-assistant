# MonEx Trade Assistant — Web Desk

Web UI for **MonEx Trade Assistant**: X login, custodial trading wallet, fund / cash out, portfolio, and activity. Buys of new tokens happen on X via `@monexmonad`; the desk can buy/sell tokens you already hold.

**Live site:** [https://trade.monexmonad.xyz](https://trade.monexmonad.xyz)

**Trade Worker:** [https://monad-x-trade-assistant.0xjericd.workers.dev/health](https://monad-x-trade-assistant.0xjericd.workers.dev/health)

> This repo previously hosted Monad Packs. The live product on `trade.monexmonad.xyz` is the Trade Assistant desk (not pack opening).

## Product flow

1. Continue with X
2. Connect browser wallet and link it to your X account
3. Add MON into the in-site trading wallet
4. Buy on X: `@monexmonad buy <amount> mon <tokenCA>`
5. Watch portfolio + activity update live on the desk
6. Optional: Export trading key once, renew wallet, or buy/sell held tokens in-app

## Stack

- Next.js 15 + OpenNext → Cloudflare Worker
- wagmi / viem (Monad mainnet, chain id `143`)
- iron-session (X OAuth)
- Trade Worker APIs (`TRADE_WORKER_URL` + `TRADE_SITE_API_SECRET`)

## Quick start

```bash
cp .env.example .env
# DATABASE_URL, SESSION_SECRET, X OAuth, TRADE_WORKER_URL, TRADE_SITE_API_SECRET

npm install
npm run dev
```

Production deploy:

```bash
npm run build:cloudflare
npx opennextjs-cloudflare deploy
```

Canonical URLs in `wrangler.jsonc` and OAuth routes use `https://trade.monexmonad.xyz`.

## X OAuth callback

In the X Developer Portal, callback must be exactly:

```text
https://trade.monexmonad.xyz/api/auth/x/callback
```

## Demo checklist

1. Open https://trade.monexmonad.xyz and complete X login
2. Fund trading wallet, then buy via X mention
3. Confirm Activity shows date/time, source, status, and explorer txn
4. Confirm bot reply on the buy tweet

Add your demo video link here when ready: `<!-- DEMO_VIDEO_URL -->`
