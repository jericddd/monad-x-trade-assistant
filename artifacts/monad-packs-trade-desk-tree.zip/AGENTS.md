# Agent instructions

Before editing or generating code in this repository, **read the full product specification**:

**[docs/monadpack-spec.md](docs/monadpack-spec.md)**

That document is the source of truth for Monad Packs. Follow it exactly.

## Required reading

1. Read `docs/monadpack-spec.md` in full before making product, UI, or architecture changes.
2. Do not use placeholder dashboard styling as the final UI. Build the shared design system before polishing individual pages.
3. Do not expand the MVP, redesign the product, or add features not listed in the spec.
4. Do not change existing MonEx game behavior. The `@monexmonad` bot is only an X command entry point for pack opens.
5. Build for **Monad Mainnet** (chain ID 143), not testnet.

## Related docs

- [docs/cloudflare-neon-deploy.md](docs/cloudflare-neon-deploy.md) — production deploy (Cloudflare Worker + Neon)
- [docs/monex-cloudflare-integration.md](docs/monex-cloudflare-integration.md) — MonEx bot webhook wiring

## When in doubt

If a task is ambiguous, resolve it using the spec. If the spec does not cover it, ask rather than inventing product behavior.
