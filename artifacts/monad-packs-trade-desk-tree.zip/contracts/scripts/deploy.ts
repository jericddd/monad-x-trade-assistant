import { ethers } from "hardhat";

async function main() {
  const [deployer] = await ethers.getSigners();
  const Factory = await ethers.getContractFactory("MonadPacksNFT");
  const nft = await Factory.deploy(deployer.address);
  await nft.waitForDeployment();
  console.log("MonadPacksNFT deployed to:", await nft.getAddress());
  console.log("Deployer/minter:", deployer.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
