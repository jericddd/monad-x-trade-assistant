Do not use placeholder dashboard styling as the final UI. Build the shared design system before polishing individual pages.

You are building a new production-ready web application called **Monad Packs**.

Read this entire specification before editing or generating code.

Do not make product assumptions.

Do not redesign the product.

Do not expand the MVP.

Do not add features that are not explicitly listed.

Do not change the existing MonEx game behavior.

The existing `@monexmonad` X bot will be reused only as an X command entry point. Monad Packs must otherwise use its own website, database tables, routes, services, activity log, pack data, and claim system.

The product must be fully responsive and optimized for desktop and mobile.

# Monad Network Requirement

This project must be built for **Monad Mainnet**, not Monad Testnet.

Use Monad Mainnet for:

* Smart contract deployment.
* NFT minting.
* Wallet network checks.
* Transaction submission.
* Contract reads.
* Explorer links.
* Final production environment configuration.

Do not use testnet addresses, testnet chain IDs, testnet RPC endpoints, testnet faucets, or testnet assumptions anywhere in the production implementation.

Before writing network configuration, verify the current official Monad Mainnet values from official Monad documentation.

The application must:

1. Detect whether the connected wallet is on Monad Mainnet.
2. Prompt the user to switch networks when necessary.
3. Add Monad Mainnet to the wallet when supported.
4. Prevent claims on the wrong network.
5. Display a clear error when the user rejects the network switch.
6. Store the production contract address through secure environment variables.
7. Never hardcode private keys or relayer credentials in frontend code.
8. Use a production-funded backend mint wallet with strict access controls.
9. Check the backend mint wallet balance before submitting claims.
10. Fail safely if the RPC, relayer, or contract is unavailable.

All claimed cards have real mainnet ownership consequences.

Because this is Mainnet:

* Do not deploy placeholder contracts accidentally.
* Do not reset or reseed claimed supply.
* Do not reuse production token IDs.
* Do not delete or rewrite successful claim records.
* Do not allow duplicate minting.
* Do not silently retry mint transactions without idempotency.
* Do not expose admin mint functions publicly.
* Do not treat production card supply as disposable test data.

Opening a pack remains offchain.

Only claiming performs a Monad Mainnet transaction.

Before any Mainnet deployment:

1. Run the complete test suite.
2. Run contract tests locally.
3. Deploy to a local development chain first.
4. Confirm claim idempotency.
5. Confirm limited supply accounting.
6. Confirm failed transactions preserve reservations.
7. Confirm admin permissions.
8. Confirm metadata URLs are permanent and publicly accessible.
9. Confirm the contract address and chain configuration.
10. Require explicit production deployment configuration.

Development environments may use local mocks or a local EVM chain, but the final deployed product and all real claims must use Monad Mainnet.


# 1. Product Summary

Monad Packs is a customizable collectible pack-opening platform.

Users can open collectible packs:

1. Through X using the existing `@monexmonad` bot.
2. Directly through the Monad Packs website.

Opening a pack does not immediately mint an NFT.

Instead:

1. The system randomly selects a card.
2. The selected card becomes reserved for that user.
3. The card remains claimable for 24 hours.
4. The user may connect a wallet and claim the card.
5. Claiming mints the card on Monad.
6. If the card is not claimed within 24 hours, it expires.
7. An expired limited card returns to the available supply.

The product philosophy is:

**Assets define the content. The platform defines the experience.**

The primary product tagline is:

**Open packs anywhere. Own them on Monad.**

# 2. Core Product Roles

## X

X is the discovery and convenience layer.

Users can open the current featured pack by posting:

`@monexmonad open pack`

Users can use the X `open pack` command only once every 24 hours.

## Website

The website is the complete product experience.

Users can:

* Browse all active packs.
* Open any website-enabled pack.
* See their pending card.
* Claim their card.
* View their collection.
* View expired pulls.
* View the public activity feed.
* View pack and card details.

Website pack opening has no cooldown.

## Monad

Monad is the ownership layer.

No blockchain transaction occurs when a pack is opened.

The blockchain is used only when a user claims a card.

# 3. Frozen User Flow

Users may begin from either X or the website.

## Flow A: Open through X

The user posts:

`@monexmonad open pack`

The existing bot infrastructure detects the command.

The pack command must be routed to the Monad Packs backend and must not enter the existing MonEx catch flow.

The backend checks:

1. The X post has not already been processed.
2. The user has not opened a pack through X within the last 24 hours.
3. The user does not currently have an unclaimed pending card.
4. A featured X pack exists and is active.
5. The featured pack is currently available.
6. At least one card in the pack is available to be pulled.

If all checks pass:

1. Open the current featured X pack.
2. Select a card using that pack’s configured draw mode.
3. Reserve the selected card for the X user.
4. Set its status to `UNCLAIMED`.
5. Set `expiresAt` to exactly 24 hours after `openedAt`.
6. Record the source as `X`.
7. Add the opening to the public activity feed.
8. Reply on X with the pulled card reveal.

The X reply must not contain:

* A transaction hash.
* A block explorer link.
* A wallet address.
* Technical blockchain details.

The reply should tell the user that the card can be claimed on the Monad Packs website within 24 hours.

The card is not yet minted.

## Flow B: Open through the website

The user visits the Monad Packs website.

The user must log in with X before opening a website pack because the pending rule and collection must be tied to a permanent X user ID.

The user may browse packs before logging in.

When the user chooses a pack and presses `Open Pack`, the backend checks:

1. The user is authenticated through X.
2. The user does not currently have an unclaimed pending card.
3. The selected pack is active.
4. The pack is enabled for website opening.
5. The pack is currently within its configured availability window.
6. At least one card is available.

There is no website cooldown.

If valid:

1. Select a card.
2. Reserve the card.
3. Set status to `UNCLAIMED`.
4. Set a 24-hour expiration.
5. Record the source as `WEBSITE`.
6. Display the card reveal immediately.
7. Add the result to the public activity feed.

The user may then connect a wallet and claim the card.

# 4. Frozen Pending Rule

A user may have only one unclaimed card at any time across the entire platform.

This pending rule applies globally across:

* X openings.
* Website openings.
* Every pack.

If the user has a pending unclaimed card:

* They cannot open another pack through X.
* They cannot open another pack through the website.
* They cannot reroll.
* They cannot replace the card.
* They cannot cancel the card.
* They cannot abandon the card early.

The user must either:

1. Claim the pending card.
2. Wait until it expires.

Once the card is claimed or expired, the user may immediately open another website pack.

The X 24-hour cooldown remains independent and does not reset when the card is claimed or expires.

Example:

A user opens through X at 3:00 PM Monday and claims at 3:05 PM.

They may immediately open a website pack after claiming.

They may not use `@monexmonad open pack` again until 3:00 PM Tuesday.

# 5. Frozen Card Statuses

Use these exact primary statuses:

* `UNCLAIMED`
* `CLAIMING`
* `CLAIMED`
* `EXPIRED`

Do not create extra statuses unless technically required for internal error handling.

## UNCLAIMED

The card is reserved.

The claim countdown is active.

## CLAIMING

A mint transaction is being submitted or confirmed.

The user must not be allowed to submit another claim transaction while this status is active.

## CLAIMED

The mint transaction succeeded.

The card belongs to the connected wallet on Monad.

The activity feed time remaining value must display:

`Done`

## EXPIRED

The 24-hour deadline passed before a successful claim.

The card cannot be claimed.

The activity feed time remaining value must display:

`0`

For limited cards, the reserved copy is returned to available supply.

# 6. Expiration Rules

Every opened card uses a 24-hour claim window for the MVP.

The expiration timestamp must be stored server-side.

Never trust the browser timer to determine whether a card is expired.

Before every opening or claim operation, the backend must check whether the user’s pending card has expired.

If expired:

1. Change status from `UNCLAIMED` to `EXPIRED`.
2. Return limited supply to the available pool.
3. Allow the user to open another website pack.
4. Keep the expired opening in activity and user history.

Create a scheduled cleanup mechanism to expire old reservations, but do not rely only on scheduled cleanup.

Expiration must also be enforced lazily during API requests.

# 7. X Cooldown Rules

The X command is:

`@monexmonad open pack`

Use strict command parsing.

Do not treat unrelated sentences containing the words “open” and “pack” as valid commands.

The command should work only when the normalized command matches the approved form.

The X pack opening cooldown is once every rolling 24 hours per permanent X user ID.

Use the permanent X user ID, not the username.

Changing an X username must not reset the cooldown or create a new account.

Deleting the original X post must not reset the cooldown.

A failed validation must not consume the cooldown.

The cooldown is consumed only after a pack opening has been successfully recorded.

A failed X reply must not undo a successful pack opening.

# 8. Featured X Pack

Only one pack may be featured on X at a time.

The command:

`@monexmonad open pack`

always opens the current featured X pack.

Users cannot choose a pack through the X command in the MVP.

The featured pack must be changeable through the admin interface without editing bot code.

When a new pack is marked as featured on X:

1. Remove featured status from the previous pack.
2. Mark the selected pack as the only featured X pack.
3. Validate that it is active and X-enabled.

If no valid featured X pack exists, the bot must reply with a friendly unavailable message and must not consume the user’s X cooldown.

# 9. Pack Asset Import System

A pack asset is already prepared before upload.

The asset is the source of truth for content.

The platform must automatically read the available information from the uploaded pack asset, including when present:

* Pack name.
* Card images.
* Card names.
* Card descriptions.
* Card metadata.
* Traits.
* Rarity information.
* Supply information.
* Original identifiers.

Do not force the admin to recreate card metadata manually.

If the asset includes a valid pack name, use it automatically.

Only ask for a manual pack name when no valid name can be detected.

After import, display an import preview before publishing.

The preview should show:

* Detected pack name.
* Number of cards detected.
* Number of new cards.
* Detected rarity information.
* Detected supply information.
* Invalid or missing assets.
* Duplicate assets.
* Proposed card numbering.

Do not publish an invalid import automatically.

# 10. Permanent Card Numbering

Cards inside each pack receive a permanent sequential display number.

Example:

Initial import:

* Monad Card #1
* Monad Card #2
* ...
* Monad Card #52

Later, 10 new cards are imported into the same pack:

* Monad Card #53
* ...
* Monad Card #62

Frozen numbering rules:

1. Existing card numbers never change.
2. New cards append after the highest number ever assigned in that pack.
3. Deleted or archived card numbers are never reused.
4. Disabled cards keep their original number.
5. Re-importing the same card must not create a duplicate number.
6. Every card must also have an internal immutable UUID or database ID.
7. The display number is scoped to the pack.
8. The internal ID is the true database reference.

Store an asset fingerprint or source identifier so the importer can detect already-imported cards.

Do not use filenames alone as the only duplicate detector.

# 11. Draw Modes

Each pack has a toggle:

`Use Asset Pull Rates`

## Toggle ON

The platform uses the rarity or pull-rate information detected from the asset to influence selection.

Do not invent a global rarity model.

Do not force:

* Common.
* Uncommon.
* Rare.
* Epic.
* Legendary.

Each asset may define its own rarity names.

If the asset contains explicit pull weights, use those weights.

If it contains rarity labels but no numerical pull rates, use a deterministic configurable rarity mapping for that pack and clearly surface the derived probabilities in the admin preview.

Do not silently invent probability values.

Require the admin to confirm generated probability mappings before publishing when numerical rates are absent.

## Toggle OFF

Ignore rarity and pull-rate metadata for random selection.

Every currently eligible card in the pack has equal probability.

Example:

52 eligible cards means each card has a `1 / 52` chance.

Rarity labels may still appear visually if they are part of the asset metadata, but they do not affect RNG.

# 12. Supply Rules

Support two card supply types:

* `UNLIMITED`
* `LIMITED`

## Unlimited

Unlimited cards never run out.

Opening or claiming an unlimited card does not reduce a maximum supply.

The platform still records how many copies have been claimed.

## Limited

Limited cards have a maximum claimable supply.

Track:

* Maximum supply.
* Claimed count.
* Reserved count.
* Available count.

Use:

`available = maxSupply - claimedCount - reservedCount`

When a limited card is opened:

1. Atomically verify available supply is greater than zero.
2. Increase reserved count.
3. Create the unclaimed opening.

When claimed:

1. Decrease reserved count.
2. Increase claimed count.

When expired:

1. Decrease reserved count.
2. Do not increase claimed count.
3. Make that copy available again.

Never allow available supply to become negative.

Prevent race conditions when two users pull the final available copy.

Use a database transaction or atomic locking strategy.

# 13. Selection Logic

A pack opening must be server-authoritative.

Never run RNG only in the browser.

For equal mode:

1. Load all active and eligible cards.
2. Remove sold-out limited cards.
3. Select one card uniformly.

For asset pull-rate mode:

1. Load all active and eligible cards.
2. Remove sold-out limited cards.
3. Apply validated asset weights.
4. Select one card using weighted random selection.

The card selection and limited supply reservation must happen atomically.

Store enough information to audit the selection:

* Pack ID.
* Eligible card count.
* Selected card ID.
* Draw mode.
* Effective weight.
* Effective estimated probability.
* Timestamp.

Do not expose sensitive implementation data unnecessarily in the user UI.

# 14. Claim Flow

A claim requires:

1. X authentication.
2. A pending unclaimed card owned by the same permanent X user ID.
3. A connected EVM wallet.
4. A wallet signature proving wallet ownership.
5. A card that has not expired.
6. A card that has not already been claimed.
7. A valid active mint configuration.

The claim process:

1. User connects wallet.
2. Backend issues a unique nonce.
3. User signs a human-readable verification message.
4. Backend verifies the signature.
5. Associate the verified wallet with the authenticated X user.
6. User clicks `Claim Card`.
7. Backend atomically changes the opening to `CLAIMING`.
8. Backend submits the mint transaction.
9. On success, store:

   * Wallet address.
   * Token ID.
   * Transaction hash.
   * Contract address.
   * Claimed timestamp.
10. Change status to `CLAIMED`.

If mint submission or confirmation fails:

* Do not mark the card claimed.
* Do not lose the reservation.
* Return the status to `UNCLAIMED` when safe.
* Allow retry while still within the claim window.
* Record the error internally.

Do not display raw private RPC errors to users.

Use a clear user-facing retry message.

# 15. Smart Contract Foundation

Use one NFT contract for the MVP unless the existing project architecture has a documented reason to use another compatible structure.

The contract should support:

* Authorized backend minting.
* Minting to a recipient wallet.
* Permanent token IDs.
* Token metadata URI.
* Card ID or card type association.
* Pack ID association.
* Duplicate claim protection.
* Mint events.

Opening packs must never call the contract.

Only successful claims mint.

The contract must not store X usernames.

The database may associate an X user with a claim, but onchain ownership should be wallet-based.

Never store private keys in frontend code.

Use secure server-side environment variables for the authorized mint wallet.

# 16. Existing MonEx Bot Integration

Reuse the existing bot infrastructure where practical:

* X authentication.
* Mention retrieval.
* Rate-limit handling.
* Reply posting.
* Existing polling or webhook infrastructure.

Do not duplicate the entire X bot stack unless necessary.

Add explicit command routing.

Example behavior:

* Existing catch command → existing MonEx handler.
* Exact `open pack` command → new Monad Packs handler.

The two product flows must use separate services and separate data.

Required separation:

* MonEx catches must not affect pack cooldowns.
* Pack openings must not affect MonEx catch limits.
* Monad Packs activity must not appear in the MonEx catch log.
* Monad Packs claims must not change MonEx inventories.
* Monad Packs database errors must not break the existing catch bot.
* The same post must not trigger both handlers.

Record processed X post IDs with a product namespace.

Example:

* Product: `MONEX`
* Product: `MONAD_PACKS`

# 17. Admin Configuration

The admin configures behavior, not card content.

For each imported pack, the admin may configure:

## Active

When disabled:

* Hide from normal website browsing.
* Prevent new openings.
* Preserve existing openings and claimed cards.

## Website Enabled

Controls whether users can open this pack on the website.

## X Enabled

Controls whether the pack is eligible to become the featured X pack.

## Featured on X

Only one pack may be featured.

## Use Asset Pull Rates

ON:

Use validated asset rarity or weight data.

OFF:

Every eligible card has equal chance.

## Claim Duration

For the MVP, default and freeze user-facing behavior to 24 hours.

The schema may support configurable duration, but do not expose multiple options unless explicitly required.

## Start Date

Optional.

## End Date

Optional.

## Visibility

For MVP:

* `PUBLIC`
* `HIDDEN`

Do not build invitation systems or private access codes.

## Pack Preview

Before publishing, show:

* Pack cover.
* Pack name.
* Total cards.
* Newly added cards.
* Card number range.
* Draw mode.
* Estimated odds.
* Supply warnings.
* Availability.
* X feature status.

# 18. Public Activity Feed

The public activity feed must show these columns:

* User
* Card
* Pack
* Source
* Opened
* Status
* Time Remaining

Example:

| User | Card | Pack | Source | Opened | Status | Time Remaining |
| @jeric | Monad Card #57 | Monad Cards | X icon | 2m ago | Unclaimed | 23h 58m |
| @alice | Molandak #8 | Monanimals | Globe icon | 18m ago | Claimed | Done |
| @bob | Monad Card #12 | Monad Cards | X icon | 1d ago | Expired | 0 |

## User

Show the current X username.

Internally use permanent X user ID.

## Card

Show card name and permanent pack display number.

## Pack

Show the pack name only.

Do not append total card count inside the activity row.

## Source

Use:

* X logo/icon for X openings.
* Globe/world icon for website openings.

Add accessible text and tooltip:

* `Opened on X`
* `Opened on Website`

Do not depend on icons alone for screen readers.

## Opened

Show a relative time such as:

* Just now.
* 2m ago.
* 3h ago.
* 1d ago.

The detailed view may show the exact timestamp.

## Status

Use:

* `Unclaimed`
* `Claimed`
* `Expired`

Do not rely only on status colors.

## Time Remaining

For `UNCLAIMED`:

Display a live countdown based on the server-provided expiration timestamp.

Examples:

* 23h 58m
* 5h 12m
* 8m 14s

For `CLAIMED`:

Display `Done`

For `EXPIRED`:

Display `0`

The countdown is visual only.

The server determines actual eligibility.

Sort activity newest first.

# 19. Activity Detail

Clicking or tapping an activity row may open a detail view showing:

* X username.
* Card image.
* Card name and number.
* Pack name.
* Source.
* Opened timestamp.
* Expiration timestamp.
* Claim timestamp when claimed.
* Current status.
* Rarity or traits when available.
* Token ID when claimed.
* Contract address when claimed.
* Transaction details when claimed.

Do not place the transaction hash or explorer link directly in the main activity table.

# 20. Main Website Pages

Build only the following primary pages for the MVP.

## Home

Contains:

* Product hero.
* Featured pack.
* Open pack call to action.
* Instructions for opening through X.
* Latest activity preview.
* Available packs preview.
* Claim reminder when the logged-in user has a pending card.

## Packs

Contains:

* All active public website-enabled packs.
* Pack cover.
* Pack name.
* Card count.
* Availability.
* Draw mode summary.
* Open button.
* Pack detail link.

## Pack Detail

Contains:

* Pack cover.
* Pack name.
* Description from asset when available.
* Total card count.
* Card preview or index.
* Draw mode.
* Rarity or equal-odds explanation.
* Supply information where applicable.
* Open Pack button.

## My Collection

Requires X login.

Contains separate sections or tabs:

* Pending.
* Claimed.
* Expired.

Allow filtering by pack.

The pending card must be visually prominent and include:

* Card image.
* Pack.
* Expiration countdown.
* Claim button.
* Connect wallet action if not connected.

## Activity

Contains the complete public activity feed.

## Admin

Protected admin-only route.

Contains:

* Pack upload/import.
* Import preview.
* Pack management.
* Feature-on-X control.
* Pack availability controls.
* Draw-mode control.
* Pack preview.
* Publish or disable actions.

# 21. Mobile Responsive Requirements

The entire application must be mobile-first and responsive.

Support at minimum:

* 320px width.
* 375px width.
* 390px width.
* 430px width.
* Tablet widths.
* Desktop widths.

Do not build a desktop table and simply allow horizontal overflow as the only mobile solution.

## Mobile Navigation

Use a compact mobile navigation pattern.

Acceptable approaches:

* Bottom navigation.
* Mobile drawer.
* Compact header with menu.

Primary actions must remain easy to reach:

* Packs.
* Pending card.
* Collection.
* Activity.

## Activity Feed Mobile Layout

On desktop, use the full table.

On mobile, convert each row into a card layout.

Example structure:

User and status on the first row.

Card and pack below.

Source icon and opened time below.

Time remaining prominently displayed.

The mobile card must still include all activity data.

## Pack Grid

Desktop:

Use multiple columns.

Tablet:

Use two columns when space permits.

Mobile:

Use one column or a carefully designed two-column card grid only if readable.

Pack names and buttons must not overflow.

## Pending Card

On mobile, the pending card and countdown must appear near the top of the collection page.

The Claim button must be full-width or otherwise easy to tap.

## Tap Targets

Interactive controls must have comfortable mobile tap targets.

Use approximately 44px minimum control height.

## Images

Use responsive image containers.

Prevent cumulative layout shift.

Use lazy loading where appropriate.

Maintain card artwork aspect ratios.

## Modals

Avoid desktop-only oversized modals.

Use bottom sheets or full-screen mobile dialogs where appropriate.

## Tables

Admin tables may use controlled horizontal scrolling if necessary, but user-facing activity must have a true mobile card version.

## Text

Prevent clipped pack names, usernames, statuses, and countdowns.

Use truncation only where the full value can still be viewed.

## Accessibility

Include:

* Keyboard navigation.
* Visible focus states.
* Semantic buttons.
* Alt text.
* Icon labels.
* Sufficient contrast.
* Reduced-motion support for reveal animation.

# 22. Pack Reveal Experience

The reveal should feel exciting but remain technically simple.

Required sequence:

1. User presses Open Pack.
2. Disable repeated submissions.
3. Show a short opening state.
4. Reveal the selected card.
5. Show:

   * Card image.
   * Card name.
   * Card number.
   * Pack name.
   * Rarity if asset metadata includes it.
   * Claim deadline.
6. Show Claim or View Pending action.

Do not make the user wait for an NFT mint during reveal.

Do not run a fake client-side RNG animation that disagrees with the server result.

The server result must be determined before the final reveal.

Respect reduced-motion settings.

# 23. Data Model Foundation

Adapt naming to the existing stack, but preserve these entities.

## User

* id
* xUserId
* xUsername
* xProfileImage
* createdAt
* updatedAt

## WalletConnection

* id
* userId
* walletAddress
* verificationNonce
* verifiedAt
* createdAt
* updatedAt

For the MVP, one active wallet per X account is sufficient.

Do not allow one wallet to be silently linked to multiple X accounts.

## Pack

* id
* sourceAssetId
* name
* slug
* description
* coverImage
* totalCards
* highestAssignedDisplayNumber
* active
* websiteEnabled
* xEnabled
* featuredOnX
* useAssetPullRates
* visibility
* startsAt
* endsAt
* createdAt
* updatedAt

## Card

* id
* packId
* sourceAssetCardId
* assetFingerprint
* displayNumber
* name
* description
* imageUrl
* metadata
* rarityLabel
* assetWeight
* supplyType
* maxSupply
* claimedCount
* reservedCount
* active
* createdAt
* updatedAt

## PackOpening

* id
* userId
* packId
* cardId
* source
* status
* sourcePostId
* openedAt
* expiresAt
* claimingAt
* claimedAt
* expiredAt
* walletAddress
* tokenId
* transactionHash
* contractAddress
* drawMode
* effectiveWeight
* createdAt
* updatedAt

## XCooldown

* id
* userId
* lastSuccessfulOpenAt
* nextAvailableAt
* createdAt
* updatedAt

## ProcessedXPost

* id
* xPostId
* product
* command
* userId
* resultOpeningId
* createdAt

## PackImport

* id
* packId
* sourceFilename
* sourceFingerprint
* status
* detectedCardCount
* newCardCount
* duplicateCount
* errorCount
* report
* createdAt
* completedAt

## ClaimAttempt

* id
* openingId
* userId
* walletAddress
* status
* transactionHash
* errorCode
* errorMessage
* createdAt
* updatedAt

Use database constraints and indexes for:

* Permanent X user ID.
* Processed X post ID and product.
* Pack slug.
* Pack card display number.
* Card asset fingerprint within pack.
* One featured X pack.
* One active unclaimed or claiming opening per user.
* Source post ID uniqueness for X openings.

# 24. Required API or Service Boundaries

Organize the code around clear services.

Recommended boundaries:

* X command parser.
* X pack command handler.
* Pack import service.
* Pack opening service.
* Card selection service.
* Supply reservation service.
* Expiration service.
* Claim service.
* Wallet verification service.
* Activity service.
* Admin pack service.
* Monad mint service.

Do not place all logic in route handlers.

Route handlers should validate input, call services, and format responses.

# 25. Concurrency and Idempotency

This section is mandatory.

Prevent:

* Duplicate X processing.
* Double-click website openings.
* Double claims.
* Two users reserving the final limited card.
* Repeated mint submissions.
* Duplicate card imports.

Use:

* Database transactions.
* Unique constraints.
* Idempotency keys.
* Server-side locks or atomic updates where supported.

For website opening, generate or accept an idempotency key.

For X, use the X post ID as the idempotency source.

For claiming, use the pack opening ID as the claim idempotency source.

# 26. Authentication and Security

Use secure X authentication.

Store the permanent X user ID.

Do not trust usernames as identity.

Use signed, HttpOnly, secure cookies where supported.

Use CSRF protection for mutating browser requests.

Validate uploaded assets.

Limit upload file size.

Reject executable files.

Sanitize metadata.

Do not render untrusted HTML from asset metadata.

Protect admin routes.

Never expose:

* X API secrets.
* Wallet private keys.
* Relayer secrets.
* Database secrets.
* RPC credentials.

Validate wallet signatures server-side.

Use nonces that expire and can only be used once.

# 27. Error Messages

Use clear product language.

Examples:

Pending card:

`You already have a pending card. Claim it or wait for it to expire before opening another pack.`

X cooldown:

`You can open another pack on X when your 24-hour cooldown ends. You can still visit the site to explore available packs.`

Expired:

`This card expired and can no longer be claimed.`

No featured pack:

`There is no featured X pack available right now.`

Sold out pack:

`This pack currently has no available cards.`

Claim failure:

`Your card is still reserved. The claim could not be completed, so please try again.`

Do not expose stack traces or raw provider messages.

# 28. Empty States

Implement intentional empty states.

Examples:

No packs:

`No packs are available right now.`

No activity:

`No packs have been opened yet.`

No claimed cards:

`Your claimed collection will appear here.`

No expired cards:

`You have no expired cards.`

No pending card:

`You do not have a pending card.`

# 29. Analytics and Basic Metrics

Track product events without adding a complex analytics dashboard.

Track:

* Pack opened.
* Opening source.
* Pack opened through X.
* Pack opened through website.
* Card claimed.
* Card expired.
* Wallet connected.
* Claim failed.
* Pack import completed.
* Featured pack changed.

Homepage summary metrics may include:

* Total packs opened.
* Cards claimed.
* Pending cards.
* Expired cards.
* Collectors.
* Opened through X.
* Opened through website.

Do not block the MVP on advanced analytics.

# 30. Testing Requirements

Add automated tests for the most important rules.

Required tests:

1. User cannot have two pending cards.
2. Website opening has no cooldown.
3. X opening has a rolling 24-hour cooldown.
4. Claiming clears the pending restriction.
5. Expiration clears the pending restriction.
6. Expired limited cards return to supply.
7. Claimed limited cards reduce available supply.
8. Equal mode gives all eligible cards equal weight.
9. Asset mode uses validated asset weights.
10. Sold-out cards cannot be selected.
11. Duplicate X post cannot create duplicate opening.
12. Double-click cannot create duplicate website opening.
13. Double claim cannot mint twice.
14. Failed claim preserves the reservation.
15. New imported cards append numbering.
16. Existing card numbers do not change.
17. Deleted card numbers are not reused.
18. Only one featured X pack exists.
19. Existing MonEx commands still route correctly.
20. Mobile activity representation includes every required field.

# 31. Build Order From 0 to 100

Follow this order.

Do not start with visual polish before the core state machine works.

## Phase 1: Repository Inspection

1. Inspect the existing repository.
2. Identify the current stack.
3. Identify the existing X bot command flow.
4. Identify authentication, database, deployment, and environment patterns.
5. Document what will be reused.
6. Document what must remain isolated.
7. Do not modify code yet until the integration points are understood.

Output a concise implementation map before coding.

## Phase 2: Database and Domain Foundation

1. Add the new Monad Packs entities.
2. Add constraints and indexes.
3. Add enums.
4. Add migrations.
5. Add service interfaces.
6. Add seed data support.
7. Confirm MonEx tables are untouched.

## Phase 3: Pack Import

1. Build asset upload.
2. Parse pack metadata.
3. Detect pack name.
4. Detect cards.
5. Compute asset fingerprints.
6. Detect duplicates.
7. Assign permanent card numbers.
8. Generate preview.
9. Add publish and reject flow.
10. Add update import for appending new cards.

## Phase 4: Admin Pack Controls

1. Build pack management page.
2. Add active toggle.
3. Add website-enabled toggle.
4. Add X-enabled toggle.
5. Add use-asset-pull-rates toggle.
6. Add availability dates.
7. Add feature-on-X control.
8. Enforce one featured pack.
9. Add preview.

## Phase 5: Website Authentication

1. Add X login.
2. Store permanent X user ID.
3. Add secure sessions.
4. Add user profile sync.
5. Confirm username changes do not create duplicates.

## Phase 6: Website Pack Opening

1. Build pack listing.
2. Build pack detail.
3. Build server-side eligibility checks.
4. Build equal draw mode.
5. Build asset draw mode.
6. Build atomic supply reservation.
7. Build pending rule.
8. Build reveal UI.
9. Add idempotency.
10. Confirm no website cooldown exists.

## Phase 7: Expiration

1. Add server expiration checks.
2. Add scheduled expiration task.
3. Return limited reservations.
4. Update activity status.
5. Unlock user opening ability.
6. Test boundary timestamps.

## Phase 8: X Bot Integration

1. Add strict `open pack` parser.
2. Add product routing.
3. Add X post idempotency.
4. Add X cooldown.
5. Load featured X pack.
6. Open and reserve card.
7. Save activity.
8. Generate bot response.
9. Confirm existing MonEx commands remain unchanged.

## Phase 9: Wallet Linking

1. Add wallet connect.
2. Add nonce endpoint.
3. Add signature verification.
4. Link wallet to X user.
5. Protect against replay.
6. Prevent silent multi-account linking.

## Phase 10: Smart Contract and Claim

1. Build or integrate NFT contract.
2. deploy to Monad Mainnet after local testing and production deployment checks.
3. Configure authorized minter.
4. Implement metadata URI strategy.
5. Build claim service.
6. Add claim idempotency.
7. Handle failed transactions.
8. Save transaction details.
9. Mark claimed only after success.

## Phase 11: Activity and Collection

1. Build public activity feed.
2. Build desktop table.
3. Build mobile activity cards.
4. Add live countdown.
5. Add detail view.
6. Build pending collection section.
7. Build claimed section.
8. Build expired section.
9. Add pack filters.

## Phase 12: Responsive UI

1. Test all pages at required widths.
2. Fix navigation.
3. Fix pack grids.
4. Fix activity mobile cards.
5. Fix pending card layout.
6. Fix dialogs.
7. Fix overflow.
8. Confirm tap targets.
9. Confirm loading and empty states.
10. Confirm reduced motion.

## Phase 13: Security and Reliability

1. Add upload validation.
2. Add admin authorization.
3. Add CSRF protection.
4. Audit environment variable use.
5. Audit concurrency.
6. Audit idempotency.
7. Audit logging.
8. Confirm no secrets reach the client.

## Phase 14: Test and Demo Preparation

1. Run migrations.
2. Import Monad Cards pack.
3. Validate detected card count.
4. Confirm numbering.
5. Enable or disable asset pull rates.
6. Set Monad Cards as featured on X.
7. Open through X.
8. Open through website.
9. Test pending block.
10. Test claim.
11. Test expiration.
12. Test limited supply release.
13. Test activity statuses.
14. Test mobile.
15. Confirm existing MonEx bot still works.

# 32. MVP Acceptance Criteria

The MVP is complete only when all of the following are true:

* A prepared pack asset can be uploaded.
* The pack name is detected automatically when present.
* Card metadata and images are imported.
* Cards receive permanent sequential numbers.
* Additional cards append without renumbering old cards.
* Admin can activate a pack.
* Admin can enable website opening.
* Admin can enable X use.
* Admin can toggle asset pull rates.
* Admin can feature exactly one pack on X.
* Users can browse packs without opening.
* Users can log in with X.
* Users can open website packs without a cooldown.
* Users can open through X once every 24 hours.
* X opens only the featured pack.
* Users cannot have more than one pending card.
* Opening does not mint.
* Pending cards expire after 24 hours.
* Limited expired cards return to supply.
* Users can connect and verify a wallet.
* Users can claim a pending card.
* Claiming mints on Monad.
* Claimed activity shows `Done`.
* Expired activity shows `0`.
* Activity shows user, card, pack, source, opened time, status, and time remaining.
* X and website sources display different icons.
* The application works properly on mobile.
* Existing MonEx functionality remains operational.

# 33. Explicitly Out of Scope

Do not build:

* Paid packs.
* Pack checkout.
* Marketplace.
* Trading.
* Card gifting.
* Card battles.
* Deck building.
* Crafting.
* Duplicate burning.
* Rerolls.
* Early discard.
* Abandon pending card.
* Tokens.
* Staking.
* Referrals.
* Leaderboards.
* Physical redemption.
* Partner self-service accounts.
* Partner APIs.
* Multi-wallet support.
* Pack selection through X.
* Multiple pending cards.
* Onchain pack opening.
* Onchain RNG.
* NFT minting before claim.

# 34. Implementation Behavior

Before editing code:

1. Inspect the repository.
2. Explain the current architecture.
3. Identify exact files that need changes.
4. Identify migration requirements.
5. Identify reused MonEx bot components.
6. Identify isolation boundaries.
7. Provide a phased implementation checklist.

Then implement one phase at a time.

After every phase:

* List files created.
* List files modified.
* Explain what now works.
* List tests added.
* List migrations or environment variables needed.
* Identify any unresolved blockers.
* Do not move unrelated files.
* Do not silently change existing MonEx behavior.

When the specification conflicts with existing code, preserve this product specification while minimizing changes to existing MonEx systems.

Do not replace the project stack.

Do not introduce unnecessary technologies.

Do not perform a broad redesign.

Build the smallest reliable implementation that satisfies every frozen rule.

You are building a new production-ready web application called **Monad Packs**.

Read this entire specification before editing or generating code.

Do not make product assumptions.

Do not redesign the product.

Do not expand the MVP.

Do not add features that are not explicitly listed.

Do not change the existing MonEx game behavior.

The existing `@monexmonad` X bot will be reused only as an X command entry point. Monad Packs must otherwise use its own website, database tables, routes, services, activity log, pack data, and claim system.

The product must be fully responsive and optimized for desktop and mobile.

# 1. Product Summary

Monad Packs is a customizable collectible pack-opening platform.

Users can open collectible packs:

1. Through X using the existing `@monexmonad` bot.
2. Directly through the Monad Packs website.

Opening a pack does not immediately mint an NFT.

Instead:

1. The system randomly selects a card.
2. The selected card becomes reserved for that user.
3. The card remains claimable for 24 hours.
4. The user may connect a wallet and claim the card.
5. Claiming mints the card on Monad.
6. If the card is not claimed within 24 hours, it expires.
7. An expired limited card returns to the available supply.

The product philosophy is:

**Assets define the content. The platform defines the experience.**

The primary product tagline is:

**Open packs anywhere. Own them on Monad.**

# 2. Core Product Roles

## X

X is the discovery and convenience layer.

Users can open the current featured pack by posting:

`@monexmonad open pack`

Users can use the X `open pack` command only once every 24 hours.

## Website

The website is the complete product experience.

Users can:

* Browse all active packs.
* Open any website-enabled pack.
* See their pending card.
* Claim their card.
* View their collection.
* View expired pulls.
* View the public activity feed.
* View pack and card details.

Website pack opening has no cooldown.

## Monad

Monad is the ownership layer.

No blockchain transaction occurs when a pack is opened.

The blockchain is used only when a user claims a card.

# 3. Frozen User Flow

Users may begin from either X or the website.

## Flow A: Open through X

The user posts:

`@monexmonad open pack`

The existing bot infrastructure detects the command.

The pack command must be routed to the Monad Packs backend and must not enter the existing MonEx catch flow.

The backend checks:

1. The X post has not already been processed.
2. The user has not opened a pack through X within the last 24 hours.
3. The user does not currently have an unclaimed pending card.
4. A featured X pack exists and is active.
5. The featured pack is currently available.
6. At least one card in the pack is available to be pulled.

If all checks pass:

1. Open the current featured X pack.
2. Select a card using that pack’s configured draw mode.
3. Reserve the selected card for the X user.
4. Set its status to `UNCLAIMED`.
5. Set `expiresAt` to exactly 24 hours after `openedAt`.
6. Record the source as `X`.
7. Add the opening to the public activity feed.
8. Reply on X with the pulled card reveal.

The X reply must not contain:

* A transaction hash.
* A block explorer link.
* A wallet address.
* Technical blockchain details.

The reply should tell the user that the card can be claimed on the Monad Packs website within 24 hours.

The card is not yet minted.

## Flow B: Open through the website

The user visits the Monad Packs website.

The user must log in with X before opening a website pack because the pending rule and collection must be tied to a permanent X user ID.

The user may browse packs before logging in.

When the user chooses a pack and presses `Open Pack`, the backend checks:

1. The user is authenticated through X.
2. The user does not currently have an unclaimed pending card.
3. The selected pack is active.
4. The pack is enabled for website opening.
5. The pack is currently within its configured availability window.
6. At least one card is available.

There is no website cooldown.

If valid:

1. Select a card.
2. Reserve the card.
3. Set status to `UNCLAIMED`.
4. Set a 24-hour expiration.
5. Record the source as `WEBSITE`.
6. Display the card reveal immediately.
7. Add the result to the public activity feed.

The user may then connect a wallet and claim the card.

# 4. Frozen Pending Rule

A user may have only one unclaimed card at any time across the entire platform.

This pending rule applies globally across:

* X openings.
* Website openings.
* Every pack.

If the user has a pending unclaimed card:

* They cannot open another pack through X.
* They cannot open another pack through the website.
* They cannot reroll.
* They cannot replace the card.
* They cannot cancel the card.
* They cannot abandon the card early.

The user must either:

1. Claim the pending card.
2. Wait until it expires.

Once the card is claimed or expired, the user may immediately open another website pack.

The X 24-hour cooldown remains independent and does not reset when the card is claimed or expires.

Example:

A user opens through X at 3:00 PM Monday and claims at 3:05 PM.

They may immediately open a website pack after claiming.

They may not use `@monexmonad open pack` again until 3:00 PM Tuesday.

# 5. Frozen Card Statuses

Use these exact primary statuses:

* `UNCLAIMED`
* `CLAIMING`
* `CLAIMED`
* `EXPIRED`

Do not create extra statuses unless technically required for internal error handling.

## UNCLAIMED

The card is reserved.

The claim countdown is active.

## CLAIMING

A mint transaction is being submitted or confirmed.

The user must not be allowed to submit another claim transaction while this status is active.

## CLAIMED

The mint transaction succeeded.

The card belongs to the connected wallet on Monad.

The activity feed time remaining value must display:

`Done`

## EXPIRED

The 24-hour deadline passed before a successful claim.

The card cannot be claimed.

The activity feed time remaining value must display:

`0`

For limited cards, the reserved copy is returned to available supply.

# 6. Expiration Rules

Every opened card uses a 24-hour claim window for the MVP.

The expiration timestamp must be stored server-side.

Never trust the browser timer to determine whether a card is expired.

Before every opening or claim operation, the backend must check whether the user’s pending card has expired.

If expired:

1. Change status from `UNCLAIMED` to `EXPIRED`.
2. Return limited supply to the available pool.
3. Allow the user to open another website pack.
4. Keep the expired opening in activity and user history.

Create a scheduled cleanup mechanism to expire old reservations, but do not rely only on scheduled cleanup.

Expiration must also be enforced lazily during API requests.

# 7. X Cooldown Rules

The X command is:

`@monexmonad open pack`

Use strict command parsing.

Do not treat unrelated sentences containing the words “open” and “pack” as valid commands.

The command should work only when the normalized command matches the approved form.

The X pack opening cooldown is once every rolling 24 hours per permanent X user ID.

Use the permanent X user ID, not the username.

Changing an X username must not reset the cooldown or create a new account.

Deleting the original X post must not reset the cooldown.

A failed validation must not consume the cooldown.

The cooldown is consumed only after a pack opening has been successfully recorded.

A failed X reply must not undo a successful pack opening.

# 8. Featured X Pack

Only one pack may be featured on X at a time.

The command:

`@monexmonad open pack`

always opens the current featured X pack.

Users cannot choose a pack through the X command in the MVP.

The featured pack must be changeable through the admin interface without editing bot code.

When a new pack is marked as featured on X:

1. Remove featured status from the previous pack.
2. Mark the selected pack as the only featured X pack.
3. Validate that it is active and X-enabled.

If no valid featured X pack exists, the bot must reply with a friendly unavailable message and must not consume the user’s X cooldown.

# 9. Pack Asset Import System

A pack asset is already prepared before upload.

The asset is the source of truth for content.

The platform must automatically read the available information from the uploaded pack asset, including when present:

* Pack name.
* Card images.
* Card names.
* Card descriptions.
* Card metadata.
* Traits.
* Rarity information.
* Supply information.
* Original identifiers.

Do not force the admin to recreate card metadata manually.

If the asset includes a valid pack name, use it automatically.

Only ask for a manual pack name when no valid name can be detected.

After import, display an import preview before publishing.

The preview should show:

* Detected pack name.
* Number of cards detected.
* Number of new cards.
* Detected rarity information.
* Detected supply information.
* Invalid or missing assets.
* Duplicate assets.
* Proposed card numbering.

Do not publish an invalid import automatically.

# 10. Permanent Card Numbering

Cards inside each pack receive a permanent sequential display number.

Example:

Initial import:

* Monad Card #1
* Monad Card #2
* ...
* Monad Card #52

Later, 10 new cards are imported into the same pack:

* Monad Card #53
* ...
* Monad Card #62

Frozen numbering rules:

1. Existing card numbers never change.
2. New cards append after the highest number ever assigned in that pack.
3. Deleted or archived card numbers are never reused.
4. Disabled cards keep their original number.
5. Re-importing the same card must not create a duplicate number.
6. Every card must also have an internal immutable UUID or database ID.
7. The display number is scoped to the pack.
8. The internal ID is the true database reference.

Store an asset fingerprint or source identifier so the importer can detect already-imported cards.

Do not use filenames alone as the only duplicate detector.

# 11. Draw Modes

Each pack has a toggle:

`Use Asset Pull Rates`

## Toggle ON

The platform uses the rarity or pull-rate information detected from the asset to influence selection.

Do not invent a global rarity model.

Do not force:

* Common.
* Uncommon.
* Rare.
* Epic.
* Legendary.

Each asset may define its own rarity names.

If the asset contains explicit pull weights, use those weights.

If it contains rarity labels but no numerical pull rates, use a deterministic configurable rarity mapping for that pack and clearly surface the derived probabilities in the admin preview.

Do not silently invent probability values.

Require the admin to confirm generated probability mappings before publishing when numerical rates are absent.

## Toggle OFF

Ignore rarity and pull-rate metadata for random selection.

Every currently eligible card in the pack has equal probability.

Example:

52 eligible cards means each card has a `1 / 52` chance.

Rarity labels may still appear visually if they are part of the asset metadata, but they do not affect RNG.

# 12. Supply Rules

Support two card supply types:

* `UNLIMITED`
* `LIMITED`

## Unlimited

Unlimited cards never run out.

Opening or claiming an unlimited card does not reduce a maximum supply.

The platform still records how many copies have been claimed.

## Limited

Limited cards have a maximum claimable supply.

Track:

* Maximum supply.
* Claimed count.
* Reserved count.
* Available count.

Use:

`available = maxSupply - claimedCount - reservedCount`

When a limited card is opened:

1. Atomically verify available supply is greater than zero.
2. Increase reserved count.
3. Create the unclaimed opening.

When claimed:

1. Decrease reserved count.
2. Increase claimed count.

When expired:

1. Decrease reserved count.
2. Do not increase claimed count.
3. Make that copy available again.

Never allow available supply to become negative.

Prevent race conditions when two users pull the final available copy.

Use a database transaction or atomic locking strategy.

# 13. Selection Logic

A pack opening must be server-authoritative.

Never run RNG only in the browser.

For equal mode:

1. Load all active and eligible cards.
2. Remove sold-out limited cards.
3. Select one card uniformly.

For asset pull-rate mode:

1. Load all active and eligible cards.
2. Remove sold-out limited cards.
3. Apply validated asset weights.
4. Select one card using weighted random selection.

The card selection and limited supply reservation must happen atomically.

Store enough information to audit the selection:

* Pack ID.
* Eligible card count.
* Selected card ID.
* Draw mode.
* Effective weight.
* Effective estimated probability.
* Timestamp.

Do not expose sensitive implementation data unnecessarily in the user UI.

# 14. Claim Flow

A claim requires:

1. X authentication.
2. A pending unclaimed card owned by the same permanent X user ID.
3. A connected EVM wallet.
4. A wallet signature proving wallet ownership.
5. A card that has not expired.
6. A card that has not already been claimed.
7. A valid active mint configuration.

The claim process:

1. User connects wallet.
2. Backend issues a unique nonce.
3. User signs a human-readable verification message.
4. Backend verifies the signature.
5. Associate the verified wallet with the authenticated X user.
6. User clicks `Claim Card`.
7. Backend atomically changes the opening to `CLAIMING`.
8. Backend submits the mint transaction.
9. On success, store:

   * Wallet address.
   * Token ID.
   * Transaction hash.
   * Contract address.
   * Claimed timestamp.
10. Change status to `CLAIMED`.

If mint submission or confirmation fails:

* Do not mark the card claimed.
* Do not lose the reservation.
* Return the status to `UNCLAIMED` when safe.
* Allow retry while still within the claim window.
* Record the error internally.

Do not display raw private RPC errors to users.

Use a clear user-facing retry message.

# 15. Smart Contract Foundation

Use one NFT contract for the MVP unless the existing project architecture has a documented reason to use another compatible structure.

The contract should support:

* Authorized backend minting.
* Minting to a recipient wallet.
* Permanent token IDs.
* Token metadata URI.
* Card ID or card type association.
* Pack ID association.
* Duplicate claim protection.
* Mint events.

Opening packs must never call the contract.

Only successful claims mint.

The contract must not store X usernames.

The database may associate an X user with a claim, but onchain ownership should be wallet-based.

Never store private keys in frontend code.

Use secure server-side environment variables for the authorized mint wallet.

# 16. Existing MonEx Bot Integration

Reuse the existing bot infrastructure where practical:

* X authentication.
* Mention retrieval.
* Rate-limit handling.
* Reply posting.
* Existing polling or webhook infrastructure.

Do not duplicate the entire X bot stack unless necessary.

Add explicit command routing.

Example behavior:

* Existing catch command → existing MonEx handler.
* Exact `open pack` command → new Monad Packs handler.

The two product flows must use separate services and separate data.

Required separation:

* MonEx catches must not affect pack cooldowns.
* Pack openings must not affect MonEx catch limits.
* Monad Packs activity must not appear in the MonEx catch log.
* Monad Packs claims must not change MonEx inventories.
* Monad Packs database errors must not break the existing catch bot.
* The same post must not trigger both handlers.

Record processed X post IDs with a product namespace.

Example:

* Product: `MONEX`
* Product: `MONAD_PACKS`

# 17. Admin Configuration

The admin configures behavior, not card content.

For each imported pack, the admin may configure:

## Active

When disabled:

* Hide from normal website browsing.
* Prevent new openings.
* Preserve existing openings and claimed cards.

## Website Enabled

Controls whether users can open this pack on the website.

## X Enabled

Controls whether the pack is eligible to become the featured X pack.

## Featured on X

Only one pack may be featured.

## Use Asset Pull Rates

ON:

Use validated asset rarity or weight data.

OFF:

Every eligible card has equal chance.

## Claim Duration

For the MVP, default and freeze user-facing behavior to 24 hours.

The schema may support configurable duration, but do not expose multiple options unless explicitly required.

## Start Date

Optional.

## End Date

Optional.

## Visibility

For MVP:

* `PUBLIC`
* `HIDDEN`

Do not build invitation systems or private access codes.

## Pack Preview

Before publishing, show:

* Pack cover.
* Pack name.
* Total cards.
* Newly added cards.
* Card number range.
* Draw mode.
* Estimated odds.
* Supply warnings.
* Availability.
* X feature status.

# 18. Public Activity Feed

The public activity feed must show these columns:

* User
* Card
* Pack
* Source
* Opened
* Status
* Time Remaining

Example:

| User | Card | Pack | Source | Opened | Status | Time Remaining |
| @jeric | Monad Card #57 | Monad Cards | X icon | 2m ago | Unclaimed | 23h 58m |
| @alice | Molandak #8 | Monanimals | Globe icon | 18m ago | Claimed | Done |
| @bob | Monad Card #12 | Monad Cards | X icon | 1d ago | Expired | 0 |

## User

Show the current X username.

Internally use permanent X user ID.

## Card

Show card name and permanent pack display number.

## Pack

Show the pack name only.

Do not append total card count inside the activity row.

## Source

Use:

* X logo/icon for X openings.
* Globe/world icon for website openings.

Add accessible text and tooltip:

* `Opened on X`
* `Opened on Website`

Do not depend on icons alone for screen readers.

## Opened

Show a relative time such as:

* Just now.
* 2m ago.
* 3h ago.
* 1d ago.

The detailed view may show the exact timestamp.

## Status

Use:

* `Unclaimed`
* `Claimed`
* `Expired`

Do not rely only on status colors.

## Time Remaining

For `UNCLAIMED`:

Display a live countdown based on the server-provided expiration timestamp.

Examples:

* 23h 58m
* 5h 12m
* 8m 14s

For `CLAIMED`:

Display `Done`

For `EXPIRED`:

Display `0`

The countdown is visual only.

The server determines actual eligibility.

Sort activity newest first.

# 19. Activity Detail

Clicking or tapping an activity row may open a detail view showing:

* X username.
* Card image.
* Card name and number.
* Pack name.
* Source.
* Opened timestamp.
* Expiration timestamp.
* Claim timestamp when claimed.
* Current status.
* Rarity or traits when available.
* Token ID when claimed.
* Contract address when claimed.
* Transaction details when claimed.

Do not place the transaction hash or explorer link directly in the main activity table.

# 20. Main Website Pages

Build only the following primary pages for the MVP.

## Home

Contains:

* Product hero.
* Featured pack.
* Open pack call to action.
* Instructions for opening through X.
* Latest activity preview.
* Available packs preview.
* Claim reminder when the logged-in user has a pending card.

## Packs

Contains:

* All active public website-enabled packs.
* Pack cover.
* Pack name.
* Card count.
* Availability.
* Draw mode summary.
* Open button.
* Pack detail link.

## Pack Detail

Contains:

* Pack cover.
* Pack name.
* Description from asset when available.
* Total card count.
* Card preview or index.
* Draw mode.
* Rarity or equal-odds explanation.
* Supply information where applicable.
* Open Pack button.

## My Collection

Requires X login.

Contains separate sections or tabs:

* Pending.
* Claimed.
* Expired.

Allow filtering by pack.

The pending card must be visually prominent and include:

* Card image.
* Pack.
* Expiration countdown.
* Claim button.
* Connect wallet action if not connected.

## Activity

Contains the complete public activity feed.

## Admin

Protected admin-only route.

Contains:

* Pack upload/import.
* Import preview.
* Pack management.
* Feature-on-X control.
* Pack availability controls.
* Draw-mode control.
* Pack preview.
* Publish or disable actions.

# 21. Mobile Responsive Requirements

The entire application must be mobile-first and responsive.

Support at minimum:

* 320px width.
* 375px width.
* 390px width.
* 430px width.
* Tablet widths.
* Desktop widths.

Do not build a desktop table and simply allow horizontal overflow as the only mobile solution.

## Mobile Navigation

Use a compact mobile navigation pattern.

Acceptable approaches:

* Bottom navigation.
* Mobile drawer.
* Compact header with menu.

Primary actions must remain easy to reach:

* Packs.
* Pending card.
* Collection.
* Activity.

## Activity Feed Mobile Layout

On desktop, use the full table.

On mobile, convert each row into a card layout.

Example structure:

User and status on the first row.

Card and pack below.

Source icon and opened time below.

Time remaining prominently displayed.

The mobile card must still include all activity data.

## Pack Grid

Desktop:

Use multiple columns.

Tablet:

Use two columns when space permits.

Mobile:

Use one column or a carefully designed two-column card grid only if readable.

Pack names and buttons must not overflow.

## Pending Card

On mobile, the pending card and countdown must appear near the top of the collection page.

The Claim button must be full-width or otherwise easy to tap.

## Tap Targets

Interactive controls must have comfortable mobile tap targets.

Use approximately 44px minimum control height.

## Images

Use responsive image containers.

Prevent cumulative layout shift.

Use lazy loading where appropriate.

Maintain card artwork aspect ratios.

## Modals

Avoid desktop-only oversized modals.

Use bottom sheets or full-screen mobile dialogs where appropriate.

## Tables

Admin tables may use controlled horizontal scrolling if necessary, but user-facing activity must have a true mobile card version.

## Text

Prevent clipped pack names, usernames, statuses, and countdowns.

Use truncation only where the full value can still be viewed.

## Accessibility

Include:

* Keyboard navigation.
* Visible focus states.
* Semantic buttons.
* Alt text.
* Icon labels.
* Sufficient contrast.
* Reduced-motion support for reveal animation.

# 22. Pack Reveal Experience

The reveal should feel exciting but remain technically simple.

Required sequence:

1. User presses Open Pack.
2. Disable repeated submissions.
3. Show a short opening state.
4. Reveal the selected card.
5. Show:

   * Card image.
   * Card name.
   * Card number.
   * Pack name.
   * Rarity if asset metadata includes it.
   * Claim deadline.
6. Show Claim or View Pending action.

Do not make the user wait for an NFT mint during reveal.

Do not run a fake client-side RNG animation that disagrees with the server result.

The server result must be determined before the final reveal.

Respect reduced-motion settings.

# 23. Data Model Foundation

Adapt naming to the existing stack, but preserve these entities.

## User

* id
* xUserId
* xUsername
* xProfileImage
* createdAt
* updatedAt

## WalletConnection

* id
* userId
* walletAddress
* verificationNonce
* verifiedAt
* createdAt
* updatedAt

For the MVP, one active wallet per X account is sufficient.

Do not allow one wallet to be silently linked to multiple X accounts.

## Pack

* id
* sourceAssetId
* name
* slug
* description
* coverImage
* totalCards
* highestAssignedDisplayNumber
* active
* websiteEnabled
* xEnabled
* featuredOnX
* useAssetPullRates
* visibility
* startsAt
* endsAt
* createdAt
* updatedAt

## Card

* id
* packId
* sourceAssetCardId
* assetFingerprint
* displayNumber
* name
* description
* imageUrl
* metadata
* rarityLabel
* assetWeight
* supplyType
* maxSupply
* claimedCount
* reservedCount
* active
* createdAt
* updatedAt

## PackOpening

* id
* userId
* packId
* cardId
* source
* status
* sourcePostId
* openedAt
* expiresAt
* claimingAt
* claimedAt
* expiredAt
* walletAddress
* tokenId
* transactionHash
* contractAddress
* drawMode
* effectiveWeight
* createdAt
* updatedAt

## XCooldown

* id
* userId
* lastSuccessfulOpenAt
* nextAvailableAt
* createdAt
* updatedAt

## ProcessedXPost

* id
* xPostId
* product
* command
* userId
* resultOpeningId
* createdAt

## PackImport

* id
* packId
* sourceFilename
* sourceFingerprint
* status
* detectedCardCount
* newCardCount
* duplicateCount
* errorCount
* report
* createdAt
* completedAt

## ClaimAttempt

* id
* openingId
* userId
* walletAddress
* status
* transactionHash
* errorCode
* errorMessage
* createdAt
* updatedAt

Use database constraints and indexes for:

* Permanent X user ID.
* Processed X post ID and product.
* Pack slug.
* Pack card display number.
* Card asset fingerprint within pack.
* One featured X pack.
* One active unclaimed or claiming opening per user.
* Source post ID uniqueness for X openings.

# 24. Required API or Service Boundaries

Organize the code around clear services.

Recommended boundaries:

* X command parser.
* X pack command handler.
* Pack import service.
* Pack opening service.
* Card selection service.
* Supply reservation service.
* Expiration service.
* Claim service.
* Wallet verification service.
* Activity service.
* Admin pack service.
* Monad mint service.

Do not place all logic in route handlers.

Route handlers should validate input, call services, and format responses.

# 25. Concurrency and Idempotency

This section is mandatory.

Prevent:

* Duplicate X processing.
* Double-click website openings.
* Double claims.
* Two users reserving the final limited card.
* Repeated mint submissions.
* Duplicate card imports.

Use:

* Database transactions.
* Unique constraints.
* Idempotency keys.
* Server-side locks or atomic updates where supported.

For website opening, generate or accept an idempotency key.

For X, use the X post ID as the idempotency source.

For claiming, use the pack opening ID as the claim idempotency source.

# 26. Authentication and Security

Use secure X authentication.

Store the permanent X user ID.

Do not trust usernames as identity.

Use signed, HttpOnly, secure cookies where supported.

Use CSRF protection for mutating browser requests.

Validate uploaded assets.

Limit upload file size.

Reject executable files.

Sanitize metadata.

Do not render untrusted HTML from asset metadata.

Protect admin routes.

Never expose:

* X API secrets.
* Wallet private keys.
* Relayer secrets.
* Database secrets.
* RPC credentials.

Validate wallet signatures server-side.

Use nonces that expire and can only be used once.

# 27. Error Messages

Use clear product language.

Examples:

Pending card:

`You already have a pending card. Claim it or wait for it to expire before opening another pack.`

X cooldown:

`You can open another pack on X when your 24-hour cooldown ends. You can still visit the site to explore available packs.`

Expired:

`This card expired and can no longer be claimed.`

No featured pack:

`There is no featured X pack available right now.`

Sold out pack:

`This pack currently has no available cards.`

Claim failure:

`Your card is still reserved. The claim could not be completed, so please try again.`

Do not expose stack traces or raw provider messages.

# 28. Empty States

Implement intentional empty states.

Examples:

No packs:

`No packs are available right now.`

No activity:

`No packs have been opened yet.`

No claimed cards:

`Your claimed collection will appear here.`

No expired cards:

`You have no expired cards.`

No pending card:

`You do not have a pending card.`

# 29. Analytics and Basic Metrics

Track product events without adding a complex analytics dashboard.

Track:

* Pack opened.
* Opening source.
* Pack opened through X.
* Pack opened through website.
* Card claimed.
* Card expired.
* Wallet connected.
* Claim failed.
* Pack import completed.
* Featured pack changed.

Homepage summary metrics may include:

* Total packs opened.
* Cards claimed.
* Pending cards.
* Expired cards.
* Collectors.
* Opened through X.
* Opened through website.

Do not block the MVP on advanced analytics.

# 30. Testing Requirements

Add automated tests for the most important rules.

Required tests:

1. User cannot have two pending cards.
2. Website opening has no cooldown.
3. X opening has a rolling 24-hour cooldown.
4. Claiming clears the pending restriction.
5. Expiration clears the pending restriction.
6. Expired limited cards return to supply.
7. Claimed limited cards reduce available supply.
8. Equal mode gives all eligible cards equal weight.
9. Asset mode uses validated asset weights.
10. Sold-out cards cannot be selected.
11. Duplicate X post cannot create duplicate opening.
12. Double-click cannot create duplicate website opening.
13. Double claim cannot mint twice.
14. Failed claim preserves the reservation.
15. New imported cards append numbering.
16. Existing card numbers do not change.
17. Deleted card numbers are not reused.
18. Only one featured X pack exists.
19. Existing MonEx commands still route correctly.
20. Mobile activity representation includes every required field.

# 31. Build Order From 0 to 100

Follow this order.

Do not start with visual polish before the core state machine works.

## Phase 1: Repository Inspection

1. Inspect the existing repository.
2. Identify the current stack.
3. Identify the existing X bot command flow.
4. Identify authentication, database, deployment, and environment patterns.
5. Document what will be reused.
6. Document what must remain isolated.
7. Do not modify code yet until the integration points are understood.

Output a concise implementation map before coding.

## Phase 2: Database and Domain Foundation

1. Add the new Monad Packs entities.
2. Add constraints and indexes.
3. Add enums.
4. Add migrations.
5. Add service interfaces.
6. Add seed data support.
7. Confirm MonEx tables are untouched.

## Phase 3: Pack Import

1. Build asset upload.
2. Parse pack metadata.
3. Detect pack name.
4. Detect cards.
5. Compute asset fingerprints.
6. Detect duplicates.
7. Assign permanent card numbers.
8. Generate preview.
9. Add publish and reject flow.
10. Add update import for appending new cards.

## Phase 4: Admin Pack Controls

1. Build pack management page.
2. Add active toggle.
3. Add website-enabled toggle.
4. Add X-enabled toggle.
5. Add use-asset-pull-rates toggle.
6. Add availability dates.
7. Add feature-on-X control.
8. Enforce one featured pack.
9. Add preview.

## Phase 5: Website Authentication

1. Add X login.
2. Store permanent X user ID.
3. Add secure sessions.
4. Add user profile sync.
5. Confirm username changes do not create duplicates.

## Phase 6: Website Pack Opening

1. Build pack listing.
2. Build pack detail.
3. Build server-side eligibility checks.
4. Build equal draw mode.
5. Build asset draw mode.
6. Build atomic supply reservation.
7. Build pending rule.
8. Build reveal UI.
9. Add idempotency.
10. Confirm no website cooldown exists.

## Phase 7: Expiration

1. Add server expiration checks.
2. Add scheduled expiration task.
3. Return limited reservations.
4. Update activity status.
5. Unlock user opening ability.
6. Test boundary timestamps.

## Phase 8: X Bot Integration

1. Add strict `open pack` parser.
2. Add product routing.
3. Add X post idempotency.
4. Add X cooldown.
5. Load featured X pack.
6. Open and reserve card.
7. Save activity.
8. Generate bot response.
9. Confirm existing MonEx commands remain unchanged.

## Phase 9: Wallet Linking

1. Add wallet connect.
2. Add nonce endpoint.
3. Add signature verification.
4. Link wallet to X user.
5. Protect against replay.
6. Prevent silent multi-account linking.

## Phase 10: Smart Contract and Claim

1. Build or integrate NFT contract.
2. deploy to Monad Mainnet after local testing and production deployment checks.
3. Configure authorized minter.
4. Implement metadata URI strategy.
5. Build claim service.
6. Add claim idempotency.
7. Handle failed transactions.
8. Save transaction details.
9. Mark claimed only after success.

## Phase 11: Activity and Collection

1. Build public activity feed.
2. Build desktop table.
3. Build mobile activity cards.
4. Add live countdown.
5. Add detail view.
6. Build pending collection section.
7. Build claimed section.
8. Build expired section.
9. Add pack filters.

## Phase 12: Responsive UI

1. Test all pages at required widths.
2. Fix navigation.
3. Fix pack grids.
4. Fix activity mobile cards.
5. Fix pending card layout.
6. Fix dialogs.
7. Fix overflow.
8. Confirm tap targets.
9. Confirm loading and empty states.
10. Confirm reduced motion.

## Phase 13: Security and Reliability

1. Add upload validation.
2. Add admin authorization.
3. Add CSRF protection.
4. Audit environment variable use.
5. Audit concurrency.
6. Audit idempotency.
7. Audit logging.
8. Confirm no secrets reach the client.

## Phase 14: Test and Demo Preparation

1. Run migrations.
2. Import Monad Cards pack.
3. Validate detected card count.
4. Confirm numbering.
5. Enable or disable asset pull rates.
6. Set Monad Cards as featured on X.
7. Open through X.
8. Open through website.
9. Test pending block.
10. Test claim.
11. Test expiration.
12. Test limited supply release.
13. Test activity statuses.
14. Test mobile.
15. Confirm existing MonEx bot still works.

# 32. MVP Acceptance Criteria

The MVP is complete only when all of the following are true:

* A prepared pack asset can be uploaded.
* The pack name is detected automatically when present.
* Card metadata and images are imported.
* Cards receive permanent sequential numbers.
* Additional cards append without renumbering old cards.
* Admin can activate a pack.
* Admin can enable website opening.
* Admin can enable X use.
* Admin can toggle asset pull rates.
* Admin can feature exactly one pack on X.
* Users can browse packs without opening.
* Users can log in with X.
* Users can open website packs without a cooldown.
* Users can open through X once every 24 hours.
* X opens only the featured pack.
* Users cannot have more than one pending card.
* Opening does not mint.
* Pending cards expire after 24 hours.
* Limited expired cards return to supply.
* Users can connect and verify a wallet.
* Users can claim a pending card.
* Claiming mints on Monad.
* Claimed activity shows `Done`.
* Expired activity shows `0`.
* Activity shows user, card, pack, source, opened time, status, and time remaining.
* X and website sources display different icons.
* The application works properly on mobile.
* Existing MonEx functionality remains operational.

# 33. Explicitly Out of Scope

Do not build:

* Paid packs.
* Pack checkout.
* Marketplace.
* Trading.
* Card gifting.
* Card battles.
* Deck building.
* Crafting.
* Duplicate burning.
* Rerolls.
* Early discard.
* Abandon pending card.
* Tokens.
* Staking.
* Referrals.
* Leaderboards.
* Physical redemption.
* Partner self-service accounts.
* Partner APIs.
* Multi-wallet support.
* Pack selection through X.
* Multiple pending cards.
* Onchain pack opening.
* Onchain RNG.
* NFT minting before claim.

# 34. Implementation Behavior

Before editing code:

1. Inspect the repository.
2. Explain the current architecture.
3. Identify exact files that need changes.
4. Identify migration requirements.
5. Identify reused MonEx bot components.
6. Identify isolation boundaries.
7. Provide a phased implementation checklist.

Then implement one phase at a time.

After every phase:

* List files created.
* List files modified.
* Explain what now works.
* List tests added.
* List migrations or environment variables needed.
* Identify any unresolved blockers.
* Do not move unrelated files.
* Do not silently change existing MonEx behavior.

When the specification conflicts with existing code, preserve this product specification while minimizing changes to existing MonEx systems.

Do not replace the project stack.

Do not introduce unnecessary technologies.

Do not perform a broad redesign.

Build the smallest reliable implementation that satisfies every frozen rule.
