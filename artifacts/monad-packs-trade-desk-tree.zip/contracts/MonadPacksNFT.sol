// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract MonadPacksNFT is ERC721, Ownable {
    mapping(bytes32 => bool) public hasMinted;
    mapping(uint256 => string) private _tokenURIs;
    uint256 private _nextTokenId = 1;
    address public minter;

    event CardMinted(
        address indexed to,
        uint256 indexed tokenId,
        bytes32 indexed openingId,
        bytes32 packId,
        bytes32 cardId,
        string tokenURI
    );

    modifier onlyMinter() {
        require(msg.sender == minter, "Not minter");
        _;
    }

    constructor(address initialOwner) ERC721("Monad Packs", "MPACK") Ownable(initialOwner) {
        minter = initialOwner;
    }

    function setMinter(address newMinter) external onlyOwner {
        minter = newMinter;
    }

    function nextTokenId() external view returns (uint256) {
        return _nextTokenId;
    }

    function mint(
        address to,
        uint256 tokenId,
        string memory tokenURI_,
        bytes32 openingId,
        bytes32 packId,
        bytes32 cardId
    ) external onlyMinter {
        require(!hasMinted[openingId], "Already minted");
        require(tokenId == _nextTokenId, "Invalid token id");

        hasMinted[openingId] = true;
        _nextTokenId++;
        _safeMint(to, tokenId);
        _tokenURIs[tokenId] = tokenURI_;

        emit CardMinted(to, tokenId, openingId, packId, cardId, tokenURI_);
    }

    function tokenURI(uint256 tokenId) public view override returns (string memory) {
        _requireOwned(tokenId);
        return _tokenURIs[tokenId];
    }
}
